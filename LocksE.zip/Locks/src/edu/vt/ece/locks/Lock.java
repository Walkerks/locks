package edu.vt.ece.locks;

public interface Lock {
	public void lock();
	public void unlock();
}
