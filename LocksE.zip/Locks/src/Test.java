import edu.vt.ece.bench.Counter;
import edu.vt.ece.bench.SharedCounter;
import edu.vt.ece.bench.TestThread;
import edu.vt.ece.locks.*;


/**
 * 
 * @author Mohamed M. Saad
 */
public class Test {

	private static final int MAX_THREAD_COUNT = 16;
	private static enum locks {ONE, TWO, PETERSON, FILTER};
	private static final String LOCK_ONE = "LockOne";
	private static final String LOCK_TWO = "LockTwo";
	private static final String PETERSON = "Peterson";
	private static final String FILTER = "Filter";
	
	private static Lock getLock(locks L, int threads){
		switch(L){
		case ONE: 
			return new LockOne();
		case TWO:
			return new LockTwo();
		case PETERSON:
			return new Peterson();
		case FILTER:
			return new Filter(threads);
		default:
			return new Filter(threads);
		}
	}

	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InterruptedException {
		String lockClass = (args.length==0 ? FILTER : args[0]);
		TestThread[] thr = new TestThread[MAX_THREAD_COUNT];
		Counter counter;// = new SharedCounter(0, new Filter(THREAD_COUNT));// (Lock)Class.forName("edu.vt.ece.locks." + lockClass).newInstance());
		System.out.print("What?");
		long startTime, stopTime;
		for (locks l : locks.values()) { 
			if(l.equals(locks.TWO)){
				continue;
			}
			
			for(int numThreads=2; numThreads <= MAX_THREAD_COUNT; numThreads=numThreads+2){
				counter = new SharedCounter(0, getLock(l, numThreads));
				startTime = System.nanoTime();
				
				for(int i = 0; i < numThreads; i++){
					thr[i] = new TestThread(counter);//.start();
					thr[i].start();
					Thread.sleep(10);
				}
				
				for(int i = 0; i < numThreads; i++){
					thr[i].join();
				}
				System.out.print("where??");
				stopTime = System.nanoTime();
				
				for(int i = 0; i < numThreads; i++){
					thr[i].clean();
					
				}

				System.out.println("LockType " + l.toString() + "  with " + numThreads + " threads took " + ((stopTime - startTime) / 1000000000.0) + " seconds " );
				if(l.equals(locks.ONE) || l.equals(locks.TWO) || l.equals(locks.PETERSON)){
					break;
				}
				
			}
			System.out.println(l.toString());
			
		}
		System.out.println("done, done");
	}
}
